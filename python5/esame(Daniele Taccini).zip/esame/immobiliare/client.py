import json, requests

base_url = 'https://127.0.0.1:8080'

def Data():

    anno: str = input('Inserisci l\'anno di nascita del cittadino: ')
    con = True

    while con:

        try:
            if len(anno) == 4:
                _ = int(anno)
                con = False
            else:
                anno: str = input('Inserisci l\'anno di nascita del cittadino: ')
        except:

            anno: str = input('Inserisci l\'anno di nascita del cittadino: ')
            
    mese: str = input('Inserisci il mese di nascita del cittadino: ')
    con = True

    while con:

        try:
            if len(mese) == 2:
                test = int(mese)
                con = False
            elif len(mese) == 1:
                test = int(mese)
                con = False
                mese = f"0{mese}"
            else:
                mese: str = input('Inserisci il mese di nascita del cittadino: ')

            if (test > 12) or (test < 1):

                con = True
                mese: str = input('Inserisci il mese di nascita del cittadino: ')
        except:

            mese: str = input('Inserisci il mese di nascita del cittadino: ')


    giorno: str = input('Inserisci il giorno di nascita del cittadino: ')
    con = True

    while con:

        try:
            if len(giorno) == 2:
                test = int(giorno)
                con = False
            elif len(giorno) == 1:
                test = int(giorno)
                con = False
                giorno = f"0{giorno}"
            else:
                giorno: str = input('Inserisci il giorno di nascita del cittadino: ')

            if (test > 31) or (test < 1):

                con = True
                giorno: str = input('Inserisci il giorno di nascita del cittadino: ')
        except:

            giorno: str = input('Inserisci il giorno di nascita del cittadino: ')        

    data = f"{anno}-{mese}-{giorno}"

    return data

def RichiediDatiCasa(user, password, scelta):

    catastale: str = input('Inserisci il codice catastale della casa: ')
    indirizzo: str = input('Inserisci il nome della via della casa: ')
    civico: str = input('Inserisci il civico della via della casa: ')
    prezzo: float = float(input('Inserisci il prezzo della casa: '))

    #vendità
    if (scelta == 0):
        piano: str = input('Inserisci il piano della casa: ')
        metri: int = int(input('Inserisci la metratura della casa: '))
        stanze: int = int(input('Inserisci il numero di stanza della casa: '))
        stato: str = 'LIBERO'

        print('Inserisci 0 se la casa non è affittata;')
        print('Inserisci 1 se la casa è affittata;')
        ris = input('--> ')

        if (ris == '1'):
            stato = 'OCCUPATO'

        jRequest = {"casa":{'catastale':catastale, 'indirizzo':indirizzo, 'civico':civico, 'piano': piano, 'metri': metri, 'stanze': stanze, 'prezzo': prezzo, 'stato': stato}
              
              , "operatore":{'user': user, 'password': password}}
    
    #affitto
    elif (scelta == 1):

        affitto: str = 'TOTALE'
        print('Inserisci 0 se l\'affitto è totale;')
        print('Inserisci 1 se l\'affitto è parziale;')
        ris = input('--> ')

        if (ris == '1'):
            affitto = 'PARZIALE'

        bagno: str = 'false'
        print('Inserisci 0 se il bagno non è personale;')
        print('Inserisci 1 se il bagno è personale;')
        ris = input('--> ')

        if (ris == '1'):
            bagno = 'true'

        jRequest = {"casa":{'catastale':catastale, 'indirizzo':indirizzo, 'civico':civico, 'affitto': affitto, 'bagno': bagno, 'prezzo': prezzo}
              
              , "operatore":{'user': user, 'password': password}}

    
    return jRequest

def EliminaCasa(user, password):
    
    catastale: str = input('Inserisci il codice castale della casa: ')

    jRequest = {"casa":{'catastale': catastale}, "operatore":{'user': user, 'password': password}}
    return jRequest

def CreaInterfaccia(permesso):

    print()
    print('        Operazioni disponibili')

    if(permesso == 'w'):
        print()
        print('1. Inserisci casa in vendità')
        print('2. elimina casa in vendità')
        print('3. Inserisci casa in affitto')
        print('4. elimina casa in affitto')
        print('5. Exit')
    
    elif(permesso == 'r'):
        print()
        print('5. Exit')

    else:
        print()
        print('5. Exit')

def accedi():
    
    print()
    user: str = input('Inserisci l\'email di login: ')
    print()
    password: str = input('Inserisci password: ')

    jRequest = {"operatore":{'user': user, 'password': password}}
    return jRequest


login = False

while login == False:

    api_url = base_url + '/accedi'
    jsonDataRequest = accedi()

    try:

        response = requests.post(api_url,json=jsonDataRequest,verify=False)
        print()
        print(response.status_code)
        print(response.headers["Content-Type"])
        data1 = response.json()
        print(data1)
    except:
        print('Problemi di connessione con il server, riprova più tardi')

    if data1['msg'] == 'ok':

        login = True
        user: str = jsonDataRequest["operatore"]['user']
        password: str = data1['user'][1]
        permesso: str = data1['user'][2]
        note: str = data1['user'][3]

if login:
    CreaInterfaccia(permesso)
    print()
    sOper = input('Selezione operazione: ')

    #Controllo permessi
    if (permesso == 'w'):

        while (sOper != '5'):    

            #'1. Inserisci casa in vendità'
            if sOper == '1':
                
                if permesso == 'w':

                    api_url = base_url + '/add_casa_vendita'
                    jsonDataRequest = RichiediDatiCasa(user, password, 0)

                    try:

                        response = requests.post(api_url,json=jsonDataRequest,verify=False)
                        print()
                        print(response.status_code)
                        print(response.headers["Content-Type"])
                        data1 = response.json()
                        print(data1)
                    except:
                        print('Problemi di connessione con il server, riprova più tardi')
                else:

                    print('Permesso negato')

            #'2. Elimina casa in vendità'
            elif sOper == '2':

                if permesso == 'w':
                    
                    api_url = base_url + '/elimina_casa_vendita'
                    jsonDataRequest = EliminaCasa(user, password)

                    try:

                        response = requests.post(api_url,json=jsonDataRequest,verify=False)
                        print()
                        print(response.status_code)
                        print(response.headers["Content-Type"])
                        
                        data1 = response.json()
                        
                        print(data1)
                        print()


                    except:
                        print('Problemi di connessione con il server, riprova più tardi')
                
                else:

                    print('Permesso Negato')

            #'3. Inserisci casa in affitto'
            elif sOper == '3':

                if(permesso == 'r')or(permesso == 'w'):

                    api_url = base_url + '/add_casa_affitto'
                    jsonDataRequest = RichiediDatiCasa(user, password, 1)

                    try:

                        response = requests.post(api_url,json=jsonDataRequest,verify=False)
                        print()
                        print(response.status_code)
                        print(response.headers["Content-Type"])
                        data1 = response.json()
                        print(data1)
                    except:
                        print('Problemi di connessione con il server, riprova più tardi')
                else:

                    print('Permesso negato')

            #'4. Elimina casa in affitto'
            elif sOper == '4':

                if permesso == 'w':
                    
                    api_url = base_url + '/elimina_casa_affitto'
                    jsonDataRequest = EliminaCasa(user, password)

                    try:

                        response = requests.post(api_url,json=jsonDataRequest,verify=False)
                        print()
                        print(response.status_code)
                        print(response.headers["Content-Type"])
                        
                        data1 = response.json()
                        
                        print(data1)
                        print()


                    except:
                        print('Problemi di connessione con il server, riprova più tardi')
                
                else:

                    print('Permesso Negato')

            elif (sOper == 5):  
                pass

            CreaInterfaccia(permesso)
            print()
            sOper = input('Selezione operazione: ')

    elif (permesso == 'r'):
        pass

        CreaInterfaccia(permesso)
        print()
        sOper = input('Selezione operazione: ')
    else :
        print('Permesso Negato')