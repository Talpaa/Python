from flask import Flask, json, request

import dbclient as db

cur = db.connect()
api = Flask(__name__)

def controllo(operatore, operazione):
    
    global cur
    #carichiamo gli utenti
    db.read_in_db(cur, f"select * from utenti where utente = '{operatore['user']}';")

    row = db.read_next_row(cur)[1]

    #controllo esistenza operatore
    if row != None:

        if operatore["password"] == row[1]:
            #carico i permessi
            permesso = row[2]

            if (operazione == 1)and(permesso == 'w'):
                
                return True, row[3]
            
            elif (operazione == 2)and((permesso == 'w')or(permesso == 'r')):
                
                return True, row[3]

            elif (operazione == 3)and(permesso == 'w'):
                
                return True, row[3]

            elif (operazione == 4)and(permesso == 'w'):
                
                return True, row[3]

            else:

                return False
        else:

            return False
    else:

        return False
    
@api.route('/accedi', methods=['POST'])
def accedi():
    global cur
    
    #prendi i dati della richiesta
    content_type = request.headers.get('Content-Type')
    print('Ricevuta chiamata ' + content_type)

    if content_type == 'application/json':

        jRequest = request.json
        user = jRequest["operatore"]['user']
        password = jRequest["operatore"]['password']

        print(f'Operatore: {jRequest["operatore"]}')

        #Prendiamo l'utente dal db
        db.read_in_db(cur, f"select * from utenti u where u.utente = '{user}';")

        row = db.read_next_row(cur)[1]

        print(row)

        #controlla che l'operatore esista
        if user in row:
            
            if password == row[1]:

                jResponse = {'Error': '000', 'msg':'ok', 'user': row} 
                return json.dumps(jResponse), 200
            
            else:

                jResponse = {'Error': '001', 'msg':'Password Errata'} 
                return json.dumps(jResponse), 200

        else:

            jResponse = {'Error': '001', 'msg':'Utente non esistente'} 
            return json.dumps(jResponse), 200
        
    else:

        return 'Errore, formato non riconosciuto', 401

    

@api.route('/add_casa_vendita', methods=['POST'])
def GestisciAddCasaVendità():
    global cur

    #prendi i dati della richiesta
    content_type = request.headers.get('Content-Type')
    print('Ricevuta chiamata ' + content_type)

    if content_type == 'application/json':

        #Dati cittadino e operatore
        jRequest = request.json
        
        sCatastale = jRequest["casa"]['catastale']
        sIndirizzo = jRequest["casa"]['indirizzo']
        sCivico = jRequest["casa"]['civico']
        sPiano = jRequest["casa"]['piano']
        sMetri = jRequest["casa"]['metri']
        sStanze = jRequest["casa"]['stanze']
        sPrezzo = jRequest["casa"]['prezzo']
        sStato = jRequest["casa"]['stato']
        print(jRequest)

        operatore = jRequest["operatore"]

        con = controllo(operatore, 1)

        if con[0]:

            #carichiamo l'anagrafe
            db.read_in_db(cur, f"select * from case_in_vendita where catastale = '{sCatastale}';")

            row = db.read_next_row(cur)[1]
            
            #controlla che il cittadino non sia già presente
            if row == None:

                sQuery = f"INSERT INTO case_in_vendita VALUES ('{sCatastale}', '{sIndirizzo}', '{sCivico}', '{sPiano}', '{sMetri}', '{sStanze}', '{sPrezzo}', '{sStato}', '{con[1]}'); "
                print(sQuery)
                ris = db.write_in_db(cur, sQuery)

                if ris == 0:

                    jResponse = {'Error': f'{ris}', 'msg':'ok'} 
                    return json.dumps(jResponse), 200
                
                else:

                    jResponse = {'Error': f'{ris}', 'msg':'ko'} 
                    return json.dumps(jResponse), 200
            else:

                jResponse = {'Error': '001', 'msg':'Codice Fiscale già presente'} 
                return json.dumps(jResponse), 200
        else:

            jResponse = {'Error': '001', 'msg':'Permesso Negato'} 
            return json.dumps(jResponse), 200
    else:

        return 'Errore, formato non riconosciuto', 401
    
@api.route('/add_casa_affitto', methods=['POST'])
def GestisciAddCasaAffitto():
    global cur

    #prendi i dati della richiesta
    content_type = request.headers.get('Content-Type')
    print('Ricevuta chiamata ' + content_type)

    if content_type == 'application/json':

        #Dati cittadino e operatore
        jRequest = request.json
        
        sCatastale = jRequest["casa"]['catastale']
        sIndirizzo = jRequest["casa"]['indirizzo']
        sCivico = jRequest["casa"]['civico']
        sPrezzo = jRequest["casa"]['prezzo']
        sAffitto = jRequest["casa"]['affitto']
        sBagno = jRequest["casa"]['bagno']
        print(jRequest)

        operatore = jRequest["operatore"]

        con = controllo(operatore, 1)

        if con[0]:

            #carichiamo l'anagrafe
            db.read_in_db(cur, f"select * from case_in_affitto where catastale = '{sCatastale}';")

            row = db.read_next_row(cur)[1]
            
            #controlla che il cittadino non sia già presente
            if row == None:

                sQuery = f"INSERT INTO case_in_affitto VALUES ('{sCatastale}', '{sIndirizzo}', '{sCivico}', '{sAffitto}', '{sBagno}', '{sPrezzo}', '{con[1]}'); "
                print(sQuery)
                ris = db.write_in_db(cur, sQuery)

                if ris == 0:

                    jResponse = {'Error': f'{ris}', 'msg':'ok'} 
                    return json.dumps(jResponse), 200
                
                else:

                    jResponse = {'Error': f'{ris}', 'msg':'ko'} 
                    return json.dumps(jResponse), 200
            else:

                jResponse = {'Error': '001', 'msg':'Codice Fiscale già presente'} 
                return json.dumps(jResponse), 200
        else:

            jResponse = {'Error': '001', 'msg':'Permesso Negato'} 
            return json.dumps(jResponse), 200
    else:

        return 'Errore, formato non riconosciuto', 401
    
@api.route('/elimina_casa_vendita', methods=['POST'])
def EliminaCasaVendita():
    global cur
    
    #prendi i dati della richiesta
    content_type = request.headers.get('Content-Type')
    print('Ricevuta chiamata ' + content_type)

    if content_type == 'application/json':

        #Dati cittadino e operatore
        jRequest = request.json
        sCatastale = jRequest["casa"]['catastale']
        print(jRequest)

        operatore = jRequest["operatore"]

        con = controllo(operatore, 4)

        if con[0]:

            #carichiamo l'anagrafe
            db.read_in_db(cur, f"select * from case_in_vendita where catastale = '{sCatastale}';")

            row = db.read_next_row(cur)[1]
            
            print(sCatastale)
            print(row)

            if sCatastale in row:

                persona = list(row)
                print(persona)

                sQuery = f"DELETE FROM case_in_vendita WHERE catastale = '{sCatastale}';"
                print(sQuery)
                ris = db.write_in_db(cur, sQuery)

                if ris == 0:

                    jResponse = {'Error': f'{ris}', 'msg':'Casa eliminata'} 
                    return json.dumps(jResponse), 200
                
                else:

                    jResponse = {'Error': f'{ris}', 'msg':'Casa non eliminata'} 
                    return json.dumps(jResponse), 200
            else:

                jResponse = {'Error': '001', 'msg':'Codice Catastale non presente'} 
                return json.dumps(jResponse), 200
        else:
            jResponse = {'Error': '001', 'msg':'Permesso Negato'} 
            return json.dumps(jResponse), 200
    else:

        return 'Errore, formato non riconosciuto', 401
    
@api.route('/elimina_casa_affitto', methods=['POST'])
def EliminaCasaAffitto():
    global cur
    
    #prendi i dati della richiesta
    content_type = request.headers.get('Content-Type')
    print('Ricevuta chiamata ' + content_type)

    if content_type == 'application/json':

        #Dati cittadino e operatore
        jRequest = request.json
        sCatastale = jRequest["casa"]['catastale']
        print(jRequest)

        operatore = jRequest["operatore"]

        con = controllo(operatore, 4)

        if con[0]:

            #carichiamo l'anagrafe
            db.read_in_db(cur, f"select * from case_in_affitto where catastale = '{sCatastale}';")

            row = db.read_next_row(cur)[1]
            
            print(sCatastale)
            print(row)

            if sCatastale in row:

                persona = list(row)
                print(persona)

                sQuery = f"DELETE FROM case_in_affitto WHERE catastale = '{sCatastale}';"
                print(sQuery)
                ris = db.write_in_db(cur, sQuery)

                if ris == 0:

                    jResponse = {'Error': f'{ris}', 'msg':'Casa eliminata'} 
                    return json.dumps(jResponse), 200
                
                else:

                    jResponse = {'Error': f'{ris}', 'msg':'Casa non eliminata'} 
                    return json.dumps(jResponse), 200
            else:

                jResponse = {'Error': '001', 'msg':'Codice Catastale non presente'} 
                return json.dumps(jResponse), 200
        else:
            jResponse = {'Error': '001', 'msg':'Permesso Negato'} 
            return json.dumps(jResponse), 200
    else:

        return 'Errore, formato non riconosciuto', 401

api.run(host='127.0.0.1', port=8080, ssl_context='adhoc')